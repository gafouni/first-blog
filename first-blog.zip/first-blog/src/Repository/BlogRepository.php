<?php
namespace App\Repository;
use App\Entity\Blog;
class BlogRepository{
    public function find(int $id): ?Blog{
        return null;
    }
}