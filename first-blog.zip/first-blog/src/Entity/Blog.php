<?php
namespace App\Entity;
class Blog{
    private int $id;
    private string $date;
    private string $author;
    private string $content;
}